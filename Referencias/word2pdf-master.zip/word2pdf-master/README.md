# word2pdf
Microservice to convert Word documents to PDFs using Flask and Docker
